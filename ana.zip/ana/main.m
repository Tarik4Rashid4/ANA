function main()
  
    
    ana = ANASingleObjective("F2");
    ana.numberOfAgents = 30;
    ana.maxIteration   = 500;
    ana.turns          = 30;
    
    % run
    ana.runANA();
    
    % print results
    ana.printMean();
    ana.printStandardDeviation();
end
